﻿Nilesoft Shell version 1.8 beta

[about]
Shell is a extensions of Windows File Explorer that can be used to create high-performance context menu items. and gives user a high level of control over context menu of Windows File Explorer.
Shell is a very lightweight utility (doesn't require installation) that is compatible with everything from Windows 7 to Windows 11.

[update]
(*) If you are updating, please first uninstall/unregister previous version.

[donate]
If you really love Shell and would like to see it continue to improve.
https://nilesoft.org/donate

[support]
https://nilesoft.org
https://nilesoft.org/github
support@nilesoft.org

[changes]
- Internal fixes and improvements
- Improved default section syntax
- str.replace bug fixed
- The following options have been moved to theme scope: (item, font, border shadow, separator, symbol)
- New option 'static-enabled' to enable or disable handle static section 
- New option 'dynamic-enabled' to enable or disable handle dynamic section 
- New option 'theme-background' to separate background color from background color of menu items
- New option 'prefix' to customize mnemonic-prefix.
- New option 'layout-align' to show submenu alignment to parent
- New option 'theme-layout-align' to enable display of image and checked together
- New options have been added to margin and padding (left, top, right, bottom)
- New options have been added to theme.item.text, theme.item.back, and and theme.symbol (normal, normal-disabled, select, select-disabled)
- New funcs color.invert, color.accent_light1, color.accent_light2 color.accent_light3 color.accent_dark1 color.accent_dark2 color.accent_dark3
- New func path.wsl to help convert the path to wsl path


[DISCLAIMER]
THE SOFTWARE IS DISTRIBUTED "AS IS". NO WARRANTY OF ANY KIND IS
EXPRESSED OR IMPLIED. YOU USE THE SOFTWARE AT YOUR OWN RISK. THE
AUTHORS WILL NOT BE LIABLE FOR DATA LOSS, DAMAGES, LOSS OF PROFITS OR
ANY OTHER KIND OF LOSS WHILE USING OR MISUSING THE SOFTWARE.

Copyright (C) 2022 Nilesoft Ltd.

[plutovg]
https://github.com/sammycage/plutovg
Copyright (c) 2020 Nwutobo Samuel Ugochukwu
